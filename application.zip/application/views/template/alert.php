<div class="container" style="padding-top: 1rem;">
	<div class="alert alert-dismissible alert-<?php echo $type; ?>">
 		<button type="button" class="close" data-dismiss="alert">&times;</button>
 		<strong><?php echo $strong; ?></strong> <?php echo $message;?>.
	</div>
</div>
