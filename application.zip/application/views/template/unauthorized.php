<div class="container" style="padding-top: 1rem;">
	<div class="alert alert-info">
 		<button type="button" class="close" data-dismiss="alert">&times;</button>
 		<strong>Oops!</strong> You are not authorized to view this page. Please contact administrator if you are supposed to be able to access this page.
	</div>
</div>
