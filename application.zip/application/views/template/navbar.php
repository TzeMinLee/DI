<div class="container-fluid">
	<nav class="navbar navbar-toggleable-md navbar-dark fixed-top bg-dark">
	    <a class="navbar-brand" href="">Darul Insyirah</a>
	</nav>
</div>