<div class="container" style="margin-top: 4rem">
	<div class="row">
		<div class="col-md-8">
			<h1 id="greeting"></h1>
			<ul class="main">
			  	<li class="date">
				    <h3>Dec 18</h3>
				    <p>Activities</p>
			  	</li>
			  	<li class= "events">
				    <ul>
				      	<li>
				          	<span class="event-time">8:00am - </span>
				          	<span>Morning Yoga</span>
				          	<br>
				          	<span class="event-location">Field</span>
				      	</li>
				      	<li>
				          	<span class="event-time">12:00pm - </span>
				          	<span>Read a book</span>
				          	<br>
				          	<span class="event-location">Library</span>
				      	</li>
				      	<li>
				          	<span class="event-time">4:00pm - </span>
				          	<span>Sriritual talk</span>
				          	<br>
				          	<span class="event-location">Main hall</span>
				      	</li>
				    </ul>
				</li>
				<li class="date">
				    <h3>Dec 19</h3>
				    <p>Activities</p>
			  	</li>
			  	<li class= "events">
				    <ul>
				      	<li>
				          	<span class="event-time">8:00am - </span>
				          	<span>Morning Jog</span>
				          	<br>
				          	<span class="event-location">Around taman</span>
				      	</li>
				      	<li>
				          	<span class="event-time">12:00pm - </span>
				          	<span>Read another book</span>
				          	<br>
				          	<span class="event-location">Library</span>
				      	</li>
				      	<li>
				          	<span class="event-time">4:00pm - </span>
				          	<span>Watch TV</span>
				          	<br>
				          	<span class="event-location">Living room</span>
				      	</li>
				    </ul>
				</li>
			</ul>
		</div>
		<div class="col-md-4">
			<table class="table table-hover">
				<thead class="thead-dark">
					<tr>
						<th>Reminders</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							Please restock medicine <i class="fa fa-exclamation blink" aria-hidden="true" style="color: red;"></i>
						</td>
					</tr>
					<tr>
						<td>
							Medical checkup
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<style>
.blink
{
	animation: blink 1s steps(5, start) infinite;
	-webkit-animation: blink 1s steps(5, start) infinite;
}
@keyframes blink
{
	to
	{
		visibility: hidden;
	}
}
@-webkit-keyframes blink
{
	to
	{
		visibility: hidden;
	}
}
ul.main
{ 
  	list-style: none;
  	max-width: 100%;
  	margin: 2rem auto;
}
h3
{
	padding: 0; margin: 0;
}

li
{
	list-style: none;
}

.date
{
	width: 20%;
  	float: left;
}

.events
{
	width: 80%;
  	float: left;
  	border-left: 1px solid #ccc;
  	margin-left: 1rem;
  	margin-bottom: 2rem;
}
.event-time
{
  	font-weight: 600;
}
.event-location
{
    font-size: .8em;
    color: tomato;
    margin-left: 70px;
}
</style>
<script>
	var now =  new Date();
	var hour = now.getHours();

	var greet = "";

	if (hour > 17)
	{
		greet = "Good Evening";
	}
	else if (hour > 12)
	{
		greet = "Good Afternoon";
	}
	else if (hour > 0)
	{
		greet = "Good Morning";
	}

	document.getElementById("greeting").innerHTML = greet;
</script>